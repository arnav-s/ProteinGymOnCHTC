STANDARD_AMINO_ACIDS = sorted("ACDEFGHIKLMNPQRSTVWY")
STANDARD_ELEMENTS = sorted(["C", "CL", "F", "H", "I", "N", "O", "P", "S"])
